# Set working directory
setwd("C:/Users/It24100755/Desktop/IT24100755")   

# 1. Import dataset
delivery <- read.table("Exercise - Lab 05.txt", header=TRUE)

# Extract column
times <- delivery$Delivery_Time_.minutes.

# 2. Histogram with 9 classes, 20–70, right-open intervals
breaks_times <- seq(20, 70, length.out=10)  # 9 classes
hist(times, breaks=breaks_times, right=FALSE,
     main="Histogram of Delivery Times",
     xlab="Delivery Time (minutes)",
     col="orange", border="black")

# 3. Frequency distribution table
freq_times <- table(cut(times, breaks=breaks_times, right=FALSE))
freq_times

# 4. Cumulative frequency polygon (ogive)
cum_freq_times <- cumsum(as.numeric(freq_times))
plot(breaks_times[-1], cum_freq_times, type="o",
     main="Cumulative Frequency Polygon (Ogive)",
     xlab="Upper Class Boundary (minutes)",
     ylab="Cumulative Frequency", col="purple", lwd=2)